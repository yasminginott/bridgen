function clickme(){
    window.location.href = 'ofer flow/offer.html'

}
